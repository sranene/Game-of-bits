package pt.ulusofona.lp2.deisiGreatGame;

public class Main {

    public static void main(String[] args) {

    }

}
